<?php

return array(
    'news' => 'news/index', //actionIndex в newsController
    'products' => 'products/list' //actionList для productController
);